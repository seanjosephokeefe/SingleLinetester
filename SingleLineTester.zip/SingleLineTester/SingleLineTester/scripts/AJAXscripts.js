﻿//AJAXscripts.js

//variables
var commonQuery = "outFields=*&f=pjson&resultRecordCount=100&returnGeometry=true&";
var DHSESAddressURL = "https://gisservices.its.ny.gov/arcgis/rest/services/Locators/Street_and_Address_Composite/GeocodeServer/findAddressCandidates?" + commonQuery + "outSR=4326&SingleLine=";
var ESRIAddressURL = "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?" + commonQuery + "outSR=4326&SingleLine=";
var globalTimeoutVar = 500;
var globalTimeout = null;
var currentAddressToSearchFor = null;

function clearResults() {
    $("#divResultsNYS").html("");
    $("#divResultsESRI").html("");
    removePointAndResetMap();
}

function getRndNumForAJAX() {
    return (Math.floor((Math.random() * 100000) + 1));
}

function performSearch(value) {
    if (value.length >= 5) {
        SearchForAddressDHSES(value);
    }
}

function buildTable(results, error, whichDiv, title, geocoder) {
    $("#" + whichDiv).html("");
    var headinghtml = '<div class="center">' + title + ' (Click on a row to map result)</div>';
    var html = "";
    var colCount = 4;
    if (error === null) {
        if (results.candidates.length > 0) {
            for (var i = 0; i < results.candidates.length; i++) {
                var address = results.candidates[i].address;
                var score = results.candidates[i].score;
                var locator = null;
                try {
                    locator = results.candidates[i].attributes.Loc_name;
                    colCount = 5;
                } catch (ex) {

                }
                var lng = results.candidates[i].location.x;
                var lat = results.candidates[i].location.y;
                html += "<tr";
                if (i % 2 === 0) {
                    html += " class='lightcyan'";
                }
                html += " onclick='addPointToMap(\"" + address + "\", \"" + geocoder + "\", " + lat + "," + lng + ",\"" + locator + "\"," + score +")'>";
                html += "<td>&nbsp;&nbsp;&nbsp;";
                html += address;
                html += "</td>";
                html += "<td align='center'>";
                html += score;
                html += "</td>";
                if (colCount === 5) {
                    html += "<td align='center'>";
                    html += locator;
                    html += "</td>";
                }
                html += "<td align='center'>";
                html += lat;
                html += "</td>";
                html += "<td align='center'>";
                html += lng;
                html += "</td>";
                html += "</tr>";
            }

        } else {
            html += "<tr><td colspan='" + colCount + "' align='center' class='lightcyan'><b>No results were returned.</b></td></tr>";
        }
    } else {
        html += "<tr><td colspan='" + colCount + "' align='center' class='lightcyan'><b>An error occurred.</b></td></tr>";
    }
    if (colCount === 5)
        headinghtml += "<table class='resultsTable'><tr><th>Address</th><th>Score</th><th>Locator</th><th>Latitude</th><th>Longitude</th></tr>";
    else {
        headinghtml += "<table class='resultsTable'><tr><th>Address</th><th>Score</th><th>Latitude</th><th>Longitude</th></tr>";
    }
    headinghtml += html + "</table>";
    $("#" + whichDiv).html(headinghtml);
}

//-----------------------------------------------------------------------------
// AJAX functions -------------------------------------------------------------
//-----------------------------------------------------------------------------
function SearchForAddressDHSES(address) {
    currentAddressToSearchFor = address;
    var thisURL = DHSESAddressURL + currentAddressToSearchFor + "&rnum=" + getRndNumForAJAX();;
    $.ajax({
        type: 'GET',
        dataType: 'jsonp',
        url: thisURL,
        success: SearchForAddressDHSES_success,
        error: SearchForAddressDHSES_failure
    });
}

function SearchForAddressDHSES_success(results) {
    SearchForAddressESRI();
    buildTable(results, null, "divResultsNYS", "NYS Geocoder Results", "NYS Geocoder", "NYS GPO");
}

function SearchForAddressDHSES_failure(error) {
    buildTable(null, error, "divResultsNYS", "NYS Geocoder Results", "ESRI Geocoder", "NYS GPO");
    SearchForAddressESRI();
}

function SearchForAddressESRI() {
    var thisURL = ESRIAddressURL + currentAddressToSearchFor + "&rnum=" + getRndNumForAJAX();
    $.ajax({
        type: 'GET',
        dataType: 'jsonp',
        url: thisURL,
        success: SearchForAddressESRI_success,
        error: SearchForAddressESRI_failure
    });
}

function SearchForAddressESRI_success(results) {
    buildTable(results, null, "divResultsESRI", "ESRI Geocoder Results", "ESRI");
}

function SearchForAddressESRI_failure(error) {
    buildTable(null, error, "divResultsESRI", "ESRI Geocoder Results", "ESRI");
}

//-----------------------------------------------------------------------------
// jQuery events --------------------------------------------------------------
//-----------------------------------------------------------------------------
$("#TBAddress").keyup(function () {
    var value = this.value;
    if (globalTimeout !== null) {
        clearTimeout(globalTimeout);
    }
    globalTimeout = setTimeout(function () {
        globalTimeout = null;
        performSearch(value);
    }, globalTimeoutVar);
});

$("#btnClearResults").click(function () {
    $("#TBAddress").val("");
    clearResults();
});