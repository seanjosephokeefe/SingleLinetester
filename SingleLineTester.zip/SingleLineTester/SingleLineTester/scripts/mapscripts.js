﻿//scripts.js

//function variables
var createSymbol = null;
var initMapLayers = null;
var addPointToMap = null;
var clearMapPoint = null;
var removePointAndResetMap = null;

//variables
var map = null;
var geometryURL = "https://gisservices-dev.dec.ny.gov/arcgis/rest/services/Utilities/Geometry/GeometryServer";
var gsvc = null;
var outSR = null;
var sls = null;;
var sfs = null;
var plottedPoint = null;
var infoTemplate = null;
var centerCoords = [-76, 43];
var initZoom = 6;

require([
    "esri/map",
    "esri/SpatialReference",
    "esri/tasks/GeometryService",
    "esri/geometry/Point",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/graphic",
    "esri/layers/GraphicsLayer",
    "esri/graphicsUtils",
    "esri/InfoTemplate",
    "esri/Color"
], function (
    Map,
    SpatialReference,
    GeometryService,
    Point,
    SimpleFillSymbol,
    SimpleLineSymbol,
    SimpleMarkerSymbol,
    Graphic,
    GraphicsLayer,
    graphicsUtils,
    InfoTemplate,
    Color
) {

    map = new Map("mapDiv", {
        basemap: "hybrid",  //For full list of pre-defined basemaps, navigate to http://arcg.is/1JVo6Wd
        center: centerCoords,
        zoom: initZoom
    });

    removePointAndResetMap=function(){
        clearMapPoint();
        map.centerAndZoom(centerCoords, initZoom);
    }

    addPointToMap = function (address, geocoder, lat, lng, locator, score) {
        gsvc = new GeometryService(geometryURL);
        outSR = new SpatialReference(102100);
        sls = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
            new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                new Color([255, 0, 0]), 2), new Color([255, 255, 0, 0.01]));
        sfs = new SimpleMarkerSymbol(SimpleMarkerSymbol.STYLE_CIRCLE, 14, new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([0, 0, 0, 1.0]), 1), new Color([255, 0, 0]));
        infoTemplate = new InfoTemplate();
        try {
            clearMapPoint();
            var content = null;
            content = "<b>Address:</b><br />${PtAddress}<br /><br /><b>Latitude:</b> ${YCoord} <br/><b>Longitude:</b> ${XCoord}<br /><br />" + 
                "<b>Locator:</b> ${Locator} <br/><b>Score:</b> ${Score}<br /><br />";
            var newPoint = {
                "geometry":
                {
                    "x": lng,
                    "y": lat,
                    "spatialReference": { "wkid": 4326 }
                },
                "attributes": {
                    "XCoord": lng.toFixed(4),
                    "YCoord": lat.toFixed(4),
                    "PtAddress": address,
                    "Locator": locator,
                    "Score": score
                },
                "symbol":
                {
                    "color": [255, 0, 0, 128],
                    "size": 12, "angle": 0, "xoffset": 0, "yoffset": 0, "type": "esriSMS",
                    "style": "esriSMSCircle",
                    "outline":
                    {
                        "color": [0, 0, 0, 255],
                        "width": 1,
                        "type": "esriSLS",
                        "style": "esriSLSSolid"
                    }
                },
                "infoTemplate":
                {
                    "title": "Search Result",
                    "content": content
                }
            };
            var gra = new Graphic(newPoint);
            gra.id = "plottedAddressPoint";
            plottedPoint = gra;
            map.graphics.add(gra);
            map.centerAndZoom(gra.geometry, 16);
        } catch (ex) {
            console.log(ex.message);
        }
    };

    clearMapPoint = function () {
        try {
            map.infoWindow.hide();
            map.graphics.remove(plottedPoint);
        } catch (ex) {
        }
    };

});